import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:loxclone/constants/colors.dart';
import 'package:loxclone/forms/common_form.dart';
import 'package:loxclone/forms/sell_car_form.dart';
import 'package:loxclone/forms/user_form_review.dart';
import 'package:loxclone/provider/category_provider.dart';
import 'package:loxclone/provider/product_provider.dart';
import 'package:loxclone/screens/auth/email_verify_screen.dart';
import 'package:loxclone/screens/auth/login_screen.dart';
import 'package:loxclone/screens/auth/phone_auth_screen.dart';
import 'package:loxclone/screens/auth/register_screen.dart';
import 'package:loxclone/screens/category/product_by_category_screen.dart';
import 'package:loxclone/screens/category/subcategory_screen.dart';
import 'package:loxclone/screens/chat/user_chat_screen.dart';
import 'package:loxclone/screens/home_screen.dart';
import 'package:loxclone/screens/location_screen.dart';
import 'package:loxclone/screens/main_navigatiion_screen.dart';
import 'package:loxclone/screens/post/my_post_screen.dart';
import 'package:loxclone/screens/product/product_details_screen.dart';
import 'package:loxclone/screens/profile_screen.dart';
import 'package:loxclone/screens/splash_screen.dart';
import 'package:loxclone/screens/welcome_screen.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/auth/reset_password_screen.dart';
import 'screens/category/category_list_screen.dart';
import 'screens/chat/chat_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await FirebaseAppCheck.instance.activate(
    webRecaptchaSiteKey: 'recaptcha-v3-site-key',
  );
  await cate();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => CategoryProvider(),
        ),
        ChangeNotifierProvider(
          create: (_) => ProductProvider(),
        )
      ],
      child: const Main(),
    ),
  );
}

cate() {
  Map<String, dynamic> map = {
    "category_name": "General Motors",
    "img": "https://png2.cleanpng.com/sh/6d1192ca9cfafea49dae598795e35508/L0KzQYm3WcA6N6hoR91yc4Pzfri0Ur0yP15ogNdBcnBvdcW0jfFtcZN6RdVqcj3qdbBskvFtNZ50jNH7cz3vf7j2TcUuPZMATNM7MUfnc4i7UcMvPGQ9UKI9OEm0RYS9VMY4PGgAUaI8LoDxd1==/kisspng-2-17-chevrolet-malibu-car-general-motors-logo-5-5b94a217dc7413.438804891536467479903.png",
    "subcategory": null,
    "models": [
      "Sedan",
      "SUV",
      "Hatchback",
      "Pickup Truck",
      "Van",
      "Wagon",
      "Convertible",
      "Coupe",
      "Roadster",
      "Bus",
      "Truck",
      "Tractor",
      "Trailer"
    ]
  };
  Map<String, dynamic> map1 = {
    "category_name": "Toyota",
    "img": "https://banner2.cleanpng.com/20171201/3ce/toyota-logo-picture-5a21ff4daacf07.7378398915121774856996.jpg",
    "subcategory": null,
    "models": [
      "Sedan",
      "SUV",
      "Hatchback",
      "Pickup Truck",
      "Van",
      "Wagon",
      "Convertible",
      "Coupe",
      "Roadster",
      "Bus",
      "Truck",
      "Tractor",
      "Trailer"
    ]
  };
  Map<String, dynamic> map2 = {
    "category_name": "Nissan",
    "img": "https://banner2.cleanpng.com/20180323/evq/kisspng-nissan-car-logo-nissan-5ab53f50017724.161120961521827664006.jpg",
    "subcategory": null,
    "models": [
      "Sedan",
      "SUV",
      "Hatchback",
      "Pickup Truck",
      "Van",
      "Wagon",
      "Convertible",
      "Coupe",
      "Roadster",
      "Bus",
      "Truck",
      "Tractor",
      "Trailer"
    ]
  };
  Map<String, dynamic> map3 = {
    "category_name": "BMW",
    "img": "https://banner2.cleanpng.com/20180630/kyl/kisspng-bmw-car-mini-logo-5b383d1216eba0.8730406215304123060939.jpg",
    "subcategory": null,
    "models": [
      "Sedan",
      "SUV",
      "Hatchback",
      "Pickup Truck",
      "Van",
      "Wagon",
      "Convertible",
      "Coupe",
      "Roadster",
      "Bus",
      "Truck",
      "Tractor",
      "Trailer"
    ]
  };
  Map<String, dynamic> map4 = {
    "category_name": "Ford",
    "img": "https://banner2.cleanpng.com/20180320/ppw/kisspng-ford-motor-company-car-ford-mustang-chrysler-ford-logo-icon-5ab0e2a0d00ac6.1520686515215417928522.jpg",
    "subcategory": null,
    "models": [
      "Sedan",
      "SUV",
      "Hatchback",
      "Pickup Truck",
      "Van",
      "Wagon",
      "Convertible",
      "Coupe",
      "Roadster",
      "Bus",
      "Truck",
      "Tractor",
      "Trailer"
    ]
  };
  Map<String, dynamic> map5 = {
    "category_name": "Honda",
    "img": "https://banner2.cleanpng.com/20180611/zjt/kisspng-honda-cr-v-car-honda-civic-type-r-honda-brio-soichiro-honda-5b1e2830980b39.4333186315287030246228.jpg",
    "subcategory": null,
    "models": [
      "Sedan",
      "SUV",
      "Hatchback",
      "Pickup Truck",
      "Van",
      "Wagon",
      "Convertible",
      "Coupe",
      "Roadster",
      "Bus",
      "Truck",
      "Tractor",
      "Trailer"
    ]
  };
  Map<String, dynamic> map6 = {
    "category_name": "Tesla",
    "img": "https://banner2.cleanpng.com/20180611/zjt/kisspng-honda-cr-v-car-honda-civic-type-r-honda-brio-soichiro-honda-5b1e2830980b39.4333186315287030246228.jpg",
    "subcategory": null,
    "models": [
      "Sedan",
      "SUV",
      "Hatchback",
      "Pickup Truck",
      "Van",
      "Wagon",
      "Convertible",
      "Coupe",
      "Roadster",
      "Bus",
      "Truck",
      "Tractor",
      "Trailer"
    ]
  };
 //  CollectionReference ref = FirebaseFirestore.instance.collection("categories");
 // ref.add(map);
 //  ref.add(map1);
 //  ref.add(map2);
 //  ref.add(map3);
 //  ref.add(map4);
 //  ref.add(map5);
 //  ref.add(map6);
//  ref.add(map7);
}

class Main extends StatelessWidget {
  const Main({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(
          primaryColor: blackColor,
          backgroundColor: whiteColor,
          fontFamily: 'Oswald',
          scaffoldBackgroundColor: whiteColor,
        ),
        debugShowCheckedModeBanner: false,
        initialRoute: SplashScreen.screenId,
        routes: {
          SplashScreen.screenId: (context) => const SplashScreen(),
          LoginScreen.screenId: (context) => const LoginScreen(),
          PhoneAuthScreen.screenId: (context) => const PhoneAuthScreen(),
          LocationScreen.screenId: (context) => const LocationScreen(),
          HomeScreen.screenId: (context) => const HomeScreen(),
          WelcomeScreen.screenId: (context) => const WelcomeScreen(),
          RegisterScreen.screenId: (context) => const RegisterScreen(),
          EmailVerifyScreen.screenId: (context) => const EmailVerifyScreen(),
          ResetPasswordScreen.screenId: (context) =>
              const ResetPasswordScreen(),
          CategoryListScreen.screenId: (context) => const CategoryListScreen(),
          SubCategoryScreen.screenId: (context) => const SubCategoryScreen(),
          MainNavigationScreen.screenId: (context) =>
              const MainNavigationScreen(),
          ChatScreen.screenId: (context) => const ChatScreen(),
          MyPostScreen.screenId: (context) => const MyPostScreen(),
          ProfileScreen.screenId: (context) => const ProfileScreen(),
          SellCarForm.screenId: (context) => const SellCarForm(),
          UserFormReview.screenId: (context) => const UserFormReview(),
          CommonForm.screenId: (context) => const CommonForm(),
          ProductDetail.screenId: (context) => const ProductDetail(),
          ProductByCategory.screenId: (context) => const ProductByCategory(),
          UserChatScreen.screenId: (context) => const UserChatScreen(),
        });
  }
}
