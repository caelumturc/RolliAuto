import 'package:email_validator/email_validator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:loxclone/constants/colors.dart';
import 'package:loxclone/constants/widgets.dart';
import 'package:loxclone/screens/welcome_screen.dart';
import 'package:loxclone/services/user.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../constants/validators.dart';
import '../services/auth.dart';
import 'location_screen.dart';
import 'main_navigatiion_screen.dart';

class ProfileScreen extends StatefulWidget {
  static const screenId = 'profile_screen';
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final GoogleSignIn googleSignIn = GoogleSignIn();
  late TextEditingController _nameController;
  late TextEditingController _countryCodeController;
  late TextEditingController _phoneNumberController;
  late TextEditingController _emailController;
  late TextEditingController _addressController;
  late FocusNode _nameNode;
  late FocusNode _countryCodeNode;
  late FocusNode _phoneNumberNode;
  late FocusNode _emailNode;
  late FocusNode _addressNode;
  UserService firebaseUser = UserService();
  @override
  void dispose() {
    _nameController.dispose();
    _countryCodeController.dispose();
    _phoneNumberController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    _nameNode.dispose();
    _countryCodeNode.dispose();
    _phoneNumberNode.dispose();
    _emailNode.dispose();
    _addressNode.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _countryCodeController = TextEditingController(text: '+1');
    _phoneNumberController = TextEditingController();
    _emailController = TextEditingController();
    _addressController = TextEditingController();
    _nameNode = FocusNode();
    _countryCodeNode = FocusNode();
    _phoneNumberNode = FocusNode();
    _emailNode = FocusNode();
    _addressNode = FocusNode();
    firebaseUser.getUserData().then((value) {
      setState(() {
        print(value);
        _nameController.text = value['name'] ?? '';
        _phoneNumberController.text = value['mobile'] ?? '';
        _emailController.text = value['email'] ?? '';
        _addressController.text = value['address']?? '';
      });
      print("valus is ${value['mobile']}");
    });
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        backgroundColor: whiteColor,
        elevation: 0,
        title: Text(
          'My Profile',
          style: TextStyle(color: blackColor),
        ),

      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CircleAvatar(
                    backgroundColor: primaryColor,
                    radius: 40,
                    child: CircleAvatar(
                      backgroundColor: secondaryColor,
                      radius: 37,
                      child: Icon(
                        CupertinoIcons.person,
                        color: whiteColor,
                        size: 40,
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    child:
                    TextFormField(
                        focusNode: _nameNode,
                        controller: _nameController,
                        validator: (value) =>
                            checkNullEmptyValidation(value, "name"),
                        keyboardType: TextInputType.text,
                        decoration: InputDecoration(
                          labelText: 'Name',
                          labelStyle: TextStyle(
                            color: greyColor,
                            fontSize: 14,
                          ),
                          errorStyle: const TextStyle(
                              color: Colors.red, fontSize: 10),
                          contentPadding: const EdgeInsets.all(15),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(color: blackColor)),
                        )),
                  )
                ],
              ),
              const SizedBox(
                height: 30,
              ),
              const Text(
                'My Details',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: TextFormField(
                        focusNode: _countryCodeNode,
                        enabled: false,
                        controller: _countryCodeController,
                        decoration: InputDecoration(
                          contentPadding: const EdgeInsets.all(15),
                          disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(color: disabledColor)),
                        )),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    flex: 3,
                    child: TextFormField(
                        focusNode: _phoneNumberNode,
                        controller: _phoneNumberController,
                        maxLength: 8,
                        maxLengthEnforcement: MaxLengthEnforcement.enforced,
                        //   validator: (value) => validateMobile(value),
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          counterText: '',
                          labelText: 'Enter your phone number',
                          labelStyle: TextStyle(
                            color: greyColor,
                            fontSize: 14,
                          ),
                          errorStyle: const TextStyle(
                              color: Colors.red, fontSize: 10),
                          contentPadding: const EdgeInsets.all(15),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(color: blackColor)),
                        )),
                  )
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              TextFormField(
                  focusNode: _emailNode,
                  controller: _emailController,
                  validator: (value) => validateEmail(
                    value,
                    EmailValidator.validate(
                      _emailController.text,
                    ),
                  ),
                  decoration: InputDecoration(
                      labelText: 'Enter your email address',
                      labelStyle: TextStyle(
                        color: greyColor,
                        fontSize: 14,
                      ),
                      errorStyle:
                      const TextStyle(color: Colors.red, fontSize: 10),
                      contentPadding: const EdgeInsets.all(15),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(color: blackColor)))),
              const SizedBox(
                height: 20,
              ),
              InkWell(
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (builder) => LocationScreen(
                        onlyPop: true,
                        popToScreen: ProfileScreen.screenId,
                      )));
                },
                child: Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                          focusNode: _addressNode,
                          enabled: false,
                          controller: _addressController,
                          validator: (value) {
                            return checkNullEmptyValidation(
                                value, 'your address');
                          },
                          minLines: 2,
                          maxLines: 4,
                          keyboardType: TextInputType.text,
                          decoration: InputDecoration(
                            labelText: 'Address',
                            labelStyle: TextStyle(
                              color: greyColor,
                              fontSize: 14,
                            ),
                            errorStyle: const TextStyle(
                                color: Colors.red, fontSize: 10),
                            contentPadding: const EdgeInsets.all(15),
                          )),
                    ),
                    Icon(Icons.arrow_forward_ios)
                  ],
                ),
              ),
              const SizedBox(height: 10,),
              if(_nameController.text!=''||_emailController.text!=''||_phoneNumberController.text!='' )
              Center(child:   ElevatedButton(
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(secondaryColor),
                      padding: MaterialStateProperty.all(
                          const EdgeInsets.symmetric(vertical: 20, horizontal: 50))),
                  onPressed: () async {
                    Auth authService = Auth();
                    var data=        {
                      'contact_details': {
                        'mobile': _phoneNumberController.text,
                        'email': _emailController.text,
                      },
                      'mobile': _phoneNumberController.text,
                      'email': _emailController.text,
                      'name': _nameController.text,
                    };
                    authService.users
                        .doc(firebaseUser.user!.uid)
                        .update(data);
                    customSnackBar(
                        context: context, content: 'User updated in the database');
                    Navigator.of(context).pushNamedAndRemoveUntil(
                        MainNavigationScreen.screenId, (route) => false);
                  },
                  child: const Text(
                    'Update User',
                  )),)

              ,  const SizedBox(height: 10,),
              Center(child:    ElevatedButton(
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(secondaryColor),
                      padding: MaterialStateProperty.all(
                          const EdgeInsets.symmetric(vertical: 20, horizontal: 50))),
                  onPressed: () async {
                    loadingDialogBox(context, 'Signing Out');

                    Navigator.of(context).pop();
                    await googleSignIn.signOut();

                    await FirebaseAuth.instance.signOut().then((value) {
                      Navigator.of(context).pushNamedAndRemoveUntil(
                          WelcomeScreen.screenId, (route) => false);
                    });
                  },
                  child: const Text(
                    'Sign Out',
                  )))
            ],
          ),
        ),
      )
    );

  }

}
