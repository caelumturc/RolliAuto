import 'package:loxclone/components/product_listing_widget.dart';
import 'package:loxclone/components/search_card.dart';
import 'package:loxclone/constants/colors.dart';
import 'package:loxclone/models/product_model.dart';
import 'package:loxclone/provider/product_provider.dart';
import 'package:loxclone/screens/product/product_details_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:search_page/search_page.dart';

class Search {
  searchQueryPage(
      {required BuildContext context,
      required List<Products> products,
      required String address,
      DocumentSnapshot? sellerDetails,
      required ProductProvider provider}) {
    showSearch(
      context: context,
      delegate: SearchPage<Products>(
          barTheme: ThemeData(
              appBarTheme: AppBarTheme(
                  backgroundColor: whiteColor,
                  elevation: 0,
                  surfaceTintColor: primaryColor,
                  iconTheme: IconThemeData(color: blackColor),
                  actionsIconTheme: IconThemeData(color: blackColor))),
          onQueryUpdate: (s) => print(s),
          items: products,
          searchLabel: 'Search any Vehicle...',
          suggestion: const SingleChildScrollView(child: ProductListing()),
          failure: const Center(
            child: Text('No product found, Please check and try again..'),
          ),
          filter: (product) => [
                product.title,
                product.description,
                product.category,
                product.subcategory,
              ],
          builder: (product) {
            return InkWell(
                onTap: () {
                  provider.setProductDetails(product.document);
                  provider.setSellerDetails(sellerDetails);
                  Navigator.pushNamed(context, ProductDetail.screenId);
                },
                child: SearchCard(
                  product: product,
                  address: address,
                ));
          }),
    );
  }
}
